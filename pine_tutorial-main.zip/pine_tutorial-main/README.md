# pine_tutorial
pine教学课程源码
 
# Pine教学课程视频地址 
 
BiBilili 视频教学： 
https://space.bilibili.com/1970832679 
 
Youtube 视频教学 
https://www.youtube.com/c/%E5%8C%BA%E5%9D%97%E6%99%AE%E6%8B%89%E6%96%AF
 
# Pine教学交流 
 
交流群：http://t.me/tvcbot8

# TradingView自动化交易
 
开源项目地址：https://github.com/blockplusim/crypto_trading_service_for_tradingview
